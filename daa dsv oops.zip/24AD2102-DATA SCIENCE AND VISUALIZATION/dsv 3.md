numpy lib intro
working with arrays 2d 3d nd
add of matrix mul of matrix

python pandas
intro to it
modifications to given inputs / dataset

ppt
dataframes
pandas

data cleaning 
removing dupes
data transformation
data visulization
context
 has tables as examples possibly from a website

pandas dataframe plots
line plots
area plots
dataframe.plot()
dataframe.plot.area()
ppt
some image with def 

bar chart using pandas dataframe
pie chart
scatterplot
box plot


 