 introduction to ds
applications of ds
uses of ds
roles in ds
ds workflow , problem def, data collection, data cleaning, exploratory data analysis, modeling, evaluation, deployment, monitoring & maintenance
ds lifecycle
evolution of ds
skills required in ds
challenges in ds 
real world impact of ds
python toolboxes
overview of toolboxes fro ds
creating  a greyscale filter for a colour image using numpy
pandas for satta manipulation using data frames
