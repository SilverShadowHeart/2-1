methods and functions in java
syntax
returnvalue methodname(parameters){

// body of the method and functions
}

define 4 functions a b c 

