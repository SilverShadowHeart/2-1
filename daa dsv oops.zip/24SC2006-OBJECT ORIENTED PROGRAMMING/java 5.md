string builder 
StringBuilder sb = new StringBuilder("initial string");
 new keyword is used to allocate some new memory space and sting builder is mutable and unlike normal strings which are immutable
stringbuilder does not guaranteed synchronization
StringClass --skipped
StringBuffer it will provide synchronizations 

String builder is faster then string buffer

works for both string builder and string buffer 
sb.append("") will add some new string to old string 
sb.insert(pos,"val");
sb.reverse()
replace(strt,end,string)
capacity()
setCharAt() (dont use this directly in print statement
substring()
deleteCharAt()
toString()


write a java program to check whether a string is palindrome or not
write a java program to count the number of words and characters in a string 
