widening conversion it is also called as automatic conversion
this is automatically done by the compiler and it converts small data type to large data type like int to double

narrowing conversion typecasting it is also known as manual conversion 
it is a method of converting big to small data type like double to int 


write a java program to display sum of squares of number from 1 to n
write a java program to display the following pattern

12345
1234
123
12
1
write a java program to display the sum of digits of a number

