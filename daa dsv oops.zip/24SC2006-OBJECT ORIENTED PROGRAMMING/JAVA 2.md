## SCANNER CLASS IN JAVA
scanner is present in utils class we have to import a package 
used for taking an input form user 

import java.util.*
import java.util.scanner

system.in

scanner has some built in methods
void - close()
pattern - delimiter() - used to place something instead of space
string - next() it will take a word until it faces a space 
byte - nextbyte() 
double -nextdouble()
float -nextfloat()
int -nextint()
string -nextstring()
long -nextlong()
short -nextshort()
void - remove()
      - skip()
      -  tostring()
      -
write a java program to read the details of the employee and print them
employee id nextint
employee name next
employee department next
employee experience float
employee salary double
employee full time or not bool
employee contact number long


what is an experssions
operandsa nd operatiors

opertaor def

operators
arthimetiv  
inc dec ment 
post ince pre incre
bitwise
relation
logical
assignemnt
ternary operatorrs
instanceof

operator precedence


associativity a = a +b ltr  a += b rtl


write a java program an employee payroll system by reading the empid basic salary
hra 30 percent da 50 % and pf  12% -16 % of the employee and calculating the hra percent da percent add calculate the gross salary (basic + hra +da - pf) and add a fixed bonus 1000 rs and print gross salary and check whether is he eligible for a loan or not if the gross is > 20000 and pf > 1000 .

id
double salary
