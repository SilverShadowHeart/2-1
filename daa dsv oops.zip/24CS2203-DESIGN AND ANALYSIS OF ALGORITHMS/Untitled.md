steps to design algorithm
calculating time complexity
calculating space complexity
psudo code instructions